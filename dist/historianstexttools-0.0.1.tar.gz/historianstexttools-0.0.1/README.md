# Historian's Text Tools

Contains tools to modify text for further processing.