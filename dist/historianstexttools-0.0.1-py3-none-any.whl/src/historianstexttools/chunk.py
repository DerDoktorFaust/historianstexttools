def chunk(number_of_sentences=1, overlap=0, language='english'):
    pass